//
//  City.swift
//  ios1
//
//  Created by mac on 2017/11/24.
//  Copyright © 2017年 mac. All rights reserved.
//

import UIKit
class City{
    var childId:String = "";
    var city:String = "";
    var continent:String = "";
    var country:String = "";
    var image:UIImage? = nil;
    var imageName:String = "";
    var local:String = "";
    var region:String = "";
}
