//
//  CustomCell.swift
//  ios1
//
//  Created by mac on 2017/11/27.
//  Copyright © 2017年 mac. All rights reserved.
//

import UIKit

class CustomCell: UICollectionViewCell {
    @IBOutlet var imageView:UIImageView!;
    @IBOutlet weak var cityLabel: UILabel!
}
