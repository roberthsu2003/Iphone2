//
//  CityCell.swift
//  ios1
//
//  Created by Robert on 2019/3/31.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class CityCell: UICollectionViewCell {
    @IBOutlet var imageView:UIImageView!
    @IBOutlet var nameLabel:UILabel!
    @IBOutlet var countryLabel:UILabel!
    @IBOutlet var continentLabel:UILabel!
}
